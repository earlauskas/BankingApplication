function Balance(){
  return (
    <h1>Balance</h1>
  )
}
